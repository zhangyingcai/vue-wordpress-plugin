<style>
    .postbox h3 {
        font-family: Georgia, "Times New Roman", "Bitstream Charter", Times, serif;
        font-size: 15px;
        padding: 10px 10px;
        margin: 0;
        line-height: 1;
    }
    #ta-table td{
        height:30px;
    }
    .wrap h2 small{
        font-size: 12px;
        margin-left: 10px;
        color: #999;
    }
</style>
<script type="text/javascript">
    jQuery(function ($) {
        $("h3.handle").click(function () {
            $(this).next(".inside").slideToggle('fast');
        });
    });
</script>

<?php

if (isset($_POST['submit1']) && $_POST['submit1'] != '') {
    $ta_password = $_POST['ta_password'];
    $ta_image_refer = isset($_POST['ta_image_refer']) && $_POST['ta_image_refer']=="true";
    $ta_unique = isset($_POST['ta_unique']) && $_POST['ta_unique']=="true";

    update_option('ta_password', $_POST['ta_password']);
    update_option('ta_image_refer', $ta_image_refer);
    update_option('ta_unique', $ta_unique);
    echo '<div id="message" class="updated fade"><p>更新成功！</p></div>';
}else{
    $ta_password = get_option('ta_password', "shenjian.io");
    $ta_image_refer = get_option('ta_image_refer', false);
    $ta_unique = get_option('ta_unique', false);
}
// 判断地址是否为内网
function isIntranet($addr){
    //验证是否是 IPv4
    if(!filter_var($addr, FILTER_VALIDATE_IP,  FILTER_FLAG_IPV4)){
        return false;
    }
    //是否为 内网
    if(!filter_var($addr, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE)){
        return true;
    }
    return false;
}

?>
<div class="wrap">
    <h2>神箭手数据发布<small>神箭手wordpress数据发布插件，可以将神箭手上爬虫采集的数据、购买的数据、导入的数据、清洗后的数据、机器学习的数据等一键发步到该网站。只需要简单的配置即可实现自动化批量发步，功能丰富强大！</small></h2>
    <br/>


    <form id="myform" method="post" action="admin.php?page=shenjian/ta-article-setting.php">
        <div class="postbox">
            <h3 class="handle" style="cursor:pointer;">发布设置</h3>
            <div class="inside">
                <table width="100%" id="ta-table">
                    <tr>
                        <td width="15%">您网站发布地址为:</td>
                        <td>
                            <?php if(isIntranet($_SERVER['HTTP_HOST'])){ ?>
                                <span class="error-message">(当前页面是通过内网访问，无法获取当前公网IP或域名，神箭手不支持发布到内网，请切换至外部网络获取网站发布地址)</span>
                            <?php }else{ ?>
                                <input id="ta_web" type="text" name="ta_web" disabled="disabled" readonly="readonly"
                                       style="width:300px" value="<?php
                                if (isset($_SERVER["HTTPS"]) && strtolower($_SERVER["HTTPS"]) == "on") {
                                    echo "https://";
                                } else {
                                    echo "http://";
                                }
                                $basicWebAddress = str_replace('\\', '/', $_SERVER['HTTP_HOST'] . str_replace('/wp-admin', '', dirname($_SERVER['SCRIPT_NAME'])));
                                echo $basicWebAddress; ?>" />
                            <?php }?>
                        </td>
                    </tr>

                    <tr>
                        <td>发布密码:</td>
                        <td><input type="text" name="ta_password" style="color:black;width:300px" value="<?php echo $ta_password; ?>" />
                        </td>
                    </tr>
                    <tr>
                        <td>是否开启图片转发:</td>
                        <td><input type="checkbox" name="ta_image_refer" value="true" <?php if($ta_image_refer == true) echo "checked='checked'" ?> />
                            <small>(开启后可解决图片防盗链，但会增加您网站服务器流量负担，不要与神箭手文件云托管同时使用)</small>
                        </td>
                    </tr>
                    <tr>
                        <td>是否标题去重:</td>
                        <td><input type="checkbox" name="ta_unique" value="true" <?php if($ta_unique == true) echo "checked='checked'" ?> />
                            <small> (不重复插入相同标题)</small>
                        </td>
                    </tr>
                    <tr>
                        <td><input type="submit" class="button-primary"  name="submit1"  value="保存更改" /></td>
                        <td>

                        </td>
                    </tr>

                </table>
            </div>
        </div>
    </form>

    <div class="postbox">
        <h3 class="handle" style="cursor:pointer;">插件信息</h3>
        <div class="inside">
            <table width="100%" id="ta-table">
                <tr>
                    <td width="15%">神箭手云官网:</td>
                    <td><a href="http://www.shenjian.io" target="_blank">www.shenjian.io</a></td>
                </tr>
                <tr>
                    <td>插件版本:</td>
                    <td>神箭手WordPress发布插件 <a href="http://www.shenjian.io/index.php?r=home/download" target="_blank">v4.2.3</a></a></td>
                </tr>
                <tr>
                    <td>
                        相关教程:
                    </td>
                    <td>
                        <div><a href="http://docs.shenjian.io/overview/guide/pub.html" target="_blank">如何发布数据</a></div>
                    </td>
                </tr>
            </table>
        </div>
        <div class="inside">
            <div>
                <p>说明：</p>
                <p>1、数据采集爬取请在神箭手官网操作（<a target="_blank" href="http://docs.shenjian.io/overview/guide/collect.html">如何爬取数据</a>），采集的数据可以通过该插件发布到wp网站</p>
                <p>2、神箭手<a target="_blank" href="http://www.shenjian.io/index.php?r=market/productList">大数据市场</a>内有很多热门网站的爬虫（包括
                    <a target="_blank" href="http://www.shenjian.io/index.php?r=market/search&keyword=%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7">微信公众号文章采集</a>、
                    <a target="_blank" href="http://www.shenjian.io/index.php?r=market/search&keyword=%E5%BE%AE%E5%8D%9A">微博采集</a>、
                    <a target="_blank" href="http://www.shenjian.io/index.php?r=market/search&keyword=%E4%BB%8A%E6%97%A5%E5%A4%B4%E6%9D%A1">今日头条采集</a>、
                    <a target="_blank" href="http://www.shenjian.io/index.php?r=market/search&keyword=%E7%BE%8E%E5%9B%A2">美团采集</a>、
                    <a target="_blank" href="http://www.shenjian.io/index.php?r=market/search&keyword=%E6%B7%98%E5%AE%9D">淘宝</a>等电商采集等），您可以免开发直接使用</p>
            </div>
        </div>
    </div>
</div>