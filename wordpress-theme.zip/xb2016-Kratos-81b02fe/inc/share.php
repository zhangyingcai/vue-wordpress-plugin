
<a href="javascript:;" id="bigger-cover" rel="nofollow">
		<i class="fa fa-picture-o"></i>
		图片
</a>
<div id="canvas" class="canvasimage">
	<header class="kratos-entry-header kratos-post-inner clearfix">
		<h1 class="kratos-entry-title"><?php the_title(); ?></h1>
		<div class="kratos-post-meta text-center">
			<span class="pull-right">
			<!-- 分类取前两个 -->
			<!-- 作品 -->
			<?php 
				$category = get_the_category(); echo '——<span class="categorys">' . $category[0] -> cat_name . '</span>';
				echo '<span class="categorys">' . $category[1] -> cat_name . '</span>';
			?>
			</span>
		</div>
	</header>
	<div class="share-int">
		<div class="qrcode" data-url="<?php the_permalink() ?>"></div>
		<p>"扫一扫"打开网站即可查看更多内容</p>
	</div>
</div>
<div class="share-wrap" style="display: none;">
	<div class="share-group">
		<a href="javascript:;" class="share-plain twitter" onclick="share('qq');" rel="nofollow">
			<div class="icon-wrap">
				<i class="fa fa-qq"></i>
			</div>
		</a>
		<a href="javascript:;" class="share-plain weibo" onclick="share('weibo');" rel="nofollow">
			<div class="icon-wrap">
				<i class="fa fa-weibo"></i>
			</div>
		</a>
		<!-- <a href="javascript:;" class="share-plain facebook style-plain" onclick="share('facebook');" rel="nofollow">
			<div class="icon-wrap">
				<i class="fa fa-facebook"></i>
			</div>
		</a>
		<a href="javascript:;" class="share-plain googleplus style-plain" onclick="share('googleplus');" rel="nofollow">
			<div class="icon-wrap">
				<i class="fa fa-google-plus"></i>
			</div>
		</a> -->
		<a href="javascript:;" class="share-plain weixin pop style-plain" rel="nofollow">
			<div class="icon-wrap">
				<i class="fa fa-weixin"></i>
			</div>
			<div class="share-int">
				<div class="qrcode" data-url="<?php the_permalink() ?>"></div>
				<p>打开微信“扫一扫”，打开网页后点击屏幕右上角分享按钮</p>
			</div>
		</a>
	</div>
	<script type="text/javascript">
	function share(obj){
		var qqShareURL="http://connect.qq.com/widget/shareqq/index.html?";
		var weiboShareURL="http://service.weibo.com/share/share.php?";
		var facebookShareURL="https://www.facebook.com/sharer/sharer.php?";
		var twitterShareURL="https://twitter.com/intent/tweet?";
		var googleplusShareURL="https://plus.google.com/share?";
		var host_url="<?php the_permalink(); ?>";
		var title='<?php  echo str_replace("%22","%2522",rawurlencode('【'.get_the_title().'】')); ?>';
		var qqtitle='<?php echo rawurlencode('【'.get_the_title().'】'); ?>';
		var excerpt='<?php echo rawurlencode(get_the_excerpt()); ?>';
		var wbexcerpt='<?php echo str_replace("%22","%2522",rawurlencode(get_the_excerpt())); ?>';
		var pic="<?php echo share_post_image(); ?>";
		var _URL;
		if(obj=="qq"){
			_URL=qqShareURL+"url="+host_url+"&title="+qqtitle+"&pics="+pic+"&desc=&summary="+excerpt+"&site=vtrois";
		}else if(obj=="weibo"){
			_URL=weiboShareURL+"url="+host_url+"&title="+title+wbexcerpt+"&pic="+pic;
		}else if(obj=="facebook"){
	 		_URL=facebookShareURL+"u="+host_url;
		}else if(obj=="twitter"){
	 		_URL=twitterShareURL+"text="+title+excerpt+"&url="+host_url;
		}else if(obj=="googleplus"){
	 		_URL=googleplusShareURL+"url="+host_url;
		}
		window.open(_URL);
	}
	//提交到wordpress自带的ajax处理
	var btn = document.getElementById("bigger-cover");
	var ele = document.getElementById("canvas");
	ele.style.width = document.getElementsByClassName('kratos-entry-header')[0].style.width;
	btn.addEventListener('click', function(){
		html2canvas(document.getElementById("canvas")).then(function(canvas) {
			console.log(canvas.style.width);
			var width = canvas.style.width;
			var height = canvas.style.height;
			var nowHeight = (Number(height.slice(0,height.indexOf('p'))) + 70 );
			height = (nowHeight> (window.screen.height-40)? window.screen.height-40 : nowHeight)+'px';
			var data = canvas.toDataURL('image/png');
			var image = new Image();
			image.src = data;
			image.style.width = canvas.style.width;
			image.style.height = canvas.style.height;
			// layer.open({
			// 	type: 1,
			// 	skin: 'layui-layer-rim', //加上边框
			// 	area: [width+'px', height+'px'], //宽高
			// 	content: '<div id="dd"></div>'
			// });
			layer.open({
				type: 1,
				skin: '', //样式类名
				closeBtn: 1, //不显示关闭按钮
				anim: 2,
				shadeClose: true, //开启遮罩关闭
				area: [width, height],
				title: false,
				content: `<div id="dd"></div><a href="${data}" class="btn-download" download="poster.jpg"><i class="fa fa-cloud-download"></i>保存图片</a>`
			});
			document.getElementById("dd").appendChild(image);
		});
	})
	</script>
</div>